img = webcam;
img = snapshot(img);
% Antag at 'img' er hentet og klar til at blive behandlet
[circleFound, circleColor, confidence] = detectColoredCircle(img);
fprintf('Circle found: %s\nCircle Color: %s\nConfidence: %.2f%%\n', ...
    circleFound, circleColor, confidence * 100);
